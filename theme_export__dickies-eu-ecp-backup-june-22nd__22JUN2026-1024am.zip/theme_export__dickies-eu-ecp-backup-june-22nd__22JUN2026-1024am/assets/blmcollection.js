import {
  u as useQueryParamsState,
  r as React,
  e as fetchBloomreachResults,
  j as jsxRuntime,
  P as ProductGridSkeleton,
  F as FilterBar,
  I as Icon,
  a as SelectedFilterChips,
  b as FilterDrawer,
  c as LoadMore,
  i as areFiltersEqual,
  d as ReactDOMClient,
} from "./bloomreach-components.MgLWQsl6.js";

function BloomreachCollectionApp() {
  const defaultFilter = window.bloomreachData?.defaultFilter ?? null;

  const [searchParams, setSearchParamsState] = useQueryParamsState(
    defaultFilter?.name
      ? { key: defaultFilter.name, value: defaultFilter.value }
      : { value: "" }
  );

  const [urlSearchParams, setUrlSearchParams] = React.useState(
    new URLSearchParams(searchParams)
  );
  const [selectedFilters, setSelectedFilters] = React.useState(
    parseFilters(urlSearchParams)
  );
  const [isLoading, setIsLoading] = React.useState(false);
  const [fetchError, setFetchError] = React.useState(null);
  const [results, setResults] = React.useState(null);

  const savedView = localStorage.getItem("view") || "compact";
  const [viewMode, setViewMode] = React.useState(savedView);

  const overlayRef = React.useRef(null);
  const drawerRef = React.useRef(null);

  const sort = urlSearchParams.get("sort") || "";
  const page = parseInt(urlSearchParams.get("page") || 0);
  const perPage = parseInt(urlSearchParams.get("perPage") || 24);

  const previousPageRef = React.useRef();

  const appliedFiltersCount = Object.keys(selectedFilters).reduce(
    (count, key) => count + selectedFilters[key].length,
    0
  );

  const collectionTitle = window.bloomreachData?.collectionTitle;

  // FIX: Prefer collectionHandle over currentCollectionId
  const collectionKey =
    window.bloomreachData?.collectionHandle ||
    window.bloomreachData?.currentCollectionId;

  const viewedProductIds = React.useRef(new Set());

  React.useEffect(() => {
    const resolvedCollectionKey =
      window.bloomreachData?.collectionHandle ||
      window.bloomreachData?.currentCollectionId;

    const currentFilters = parseFilters(urlSearchParams);

    if (resolvedCollectionKey) {
      setIsLoading(true);
      setFetchError(null);

      fetchCollectionResults(
        results,
        resolvedCollectionKey,
        previousPageRef.current,
        page,
        perPage,
        sort,
        currentFilters
      )
        .then((response) => {
          setIsLoading(false);
          setResults(response);
        })
        .catch((error) => {
          setIsLoading(false);
          console.error("Error fetching results:", error);
          setResults(null);
          setFetchError(error);
        });
    }

    previousPageRef.current = parseInt(page);
    console.groupEnd();
  }, [urlSearchParams]);

  React.useEffect(() => {
    const docs = results?.response?.docs;

    if (!docs || !docs.length) return;

    const untrackedDocs = docs.filter(
      (doc) => !viewedProductIds.current.has(String(doc.pid))
    );

    if (!untrackedDocs.length) return;

    const batches = [];
    for (let i = 0; i < untrackedDocs.length; i += 24) {
      batches.push(untrackedDocs.slice(i, i + 24));
    }

    batches.forEach((batch, batchIndex) => {
      const items = batch.map((product) => {
        let availableColors = [];

        if (typeof product.availableColors === "string") {
          try {
            availableColors = JSON.parse(product.availableColors);
          } catch (error) {
            console.error("Failed to parse availableColors JSON:", error);
          }
        }

        const currentColor = product.variants?.[0]?.sku_color?.toLowerCase();
        const matchedColor = availableColors.find(
          (color) => color.name.toLowerCase() === currentColor
        );

        return {
          colorDescription: product.variants?.[0]?.sku_color,
          item_id: String(product.pid),
          item_name: product.title,
          price: product.lowCurrent,
          item_compare_at_price: product.highOriginal,
          discount:
            product.highOriginal && product.lowCurrent
              ? product.highOriginal - product.lowCurrent
              : 0,
          onSale: product.highOriginal > product.lowCurrent,
          quantity: 1,
          product_id: matchedColor?.id || null,
          item_list_name: collectionTitle,
          item_list_id: collectionKey,
        };
      });

      window.dataLayer = window.dataLayer || [];
      window.dataLayer.push({
        event: "view_item_list",
        item_list_name: collectionTitle,
        item_list_id: collectionKey,
        batch: Math.floor(viewedProductIds.current.size / 24) + batchIndex + 1,
        ecommerce: {
          items,
        },
      });
    });

    untrackedDocs.forEach((doc) => {
      viewedProductIds.current.add(String(doc.pid));
    });
  }, [results, collectionTitle, collectionKey]);

  async function fetchCollectionResults(
    existingResults,
    collectionIdentifier,
    previousPage,
    currentPage,
    perPageValue,
    sortValue,
    filters
  ) {
    const existingDocs = existingResults?.response?.docs;

    if (existingDocs && existingDocs.length > 0 && currentPage > previousPage) {
      const startOffset = currentPage * perPageValue;

      const response = await fetchBloomreachResults(
        collectionIdentifier,
        startOffset,
        perPageValue,
        sortValue,
        filters
      );

      const newDocs = response?.response?.docs || [];
      response.response.docs = [...existingDocs, ...newDocs];
      return response;
    }

    const totalNeeded = (currentPage + 1) * perPageValue;

    if (totalNeeded <= 200) {
      return fetchBloomreachResults(
        collectionIdentifier,
        0,
        totalNeeded,
        sortValue,
        filters
      );
    }

    let mergedResponse = null;
    let loadedCount = 0;

    while (loadedCount < totalNeeded) {
      const remaining = totalNeeded - loadedCount;
      const chunkSize = Math.min(remaining, 200);
      const offset = loadedCount;

      try {
        const response = await fetchBloomreachResults(
          collectionIdentifier,
          offset,
          chunkSize,
          sortValue,
          filters
        );

        if (!mergedResponse) {
          mergedResponse = response;
        } else {
          const chunkDocs = response?.response?.docs || [];
          if (mergedResponse.response?.docs) {
            mergedResponse.response.docs.push(...chunkDocs);
          }
        }

        const fetchedCount = (response?.response?.docs || []).length;
        loadedCount += fetchedCount;

        if (fetchedCount < chunkSize) break;
      } catch (error) {
        console.error(`Error fetching chunk starting at ${offset}:`, error);
        return mergedResponse || Promise.reject(error);
      }
    }

    return mergedResponse;
  }

  function updateGlobalQueryParams(key, value) {
    const nextParams = new URLSearchParams(searchParams);

    if (!value || (Array.isArray(value) && value.length === 0)) {
      nextParams.delete(key);
    } else if (Array.isArray(value)) {
      nextParams.delete(key);
      value.forEach((entry) => {
        nextParams.append(key, entry);
      });
    } else {
      nextParams.set(key, value);
    }

    updateUrlParams(nextParams);
  }

  function updateUrlParams(nextParams) {
    setSearchParamsState(nextParams);
    setUrlSearchParams(nextParams);

    const nextFilters = parseFilters(nextParams);

    setSelectedFilters((previousFilters) => {
      if (!areFiltersEqual(previousFilters, nextFilters)) {
        viewedProductIds.current = new Set();
      }
      return nextFilters;
    });
  }

  function parseFilters(params) {
    const filters = {};

    for (const key of params.keys()) {
      if (key.startsWith("f_")) {
        const filterKey = key.replace("f_", "");
        const values = params.getAll(key);
        filters[filterKey] = values;
      }
    }

    return filters;
  }

  function openFiltersDrawer() {
    overlayRef.current.style.display = "block";
    drawerRef.current.dataset.active = true;
  }

  function loadMore() {
    updateGlobalQueryParams("page", page + 1);
  }

  function clearAllFilters() {
    setSelectedFilters((previousFilters) => {
      if (!areFiltersEqual(previousFilters, {})) {
        viewedProductIds.current = new Set();
      }
      return {};
    });

    const findValue = searchParams.get("find") || "";

    if (findValue === "") {
      updateUrlParams(new URLSearchParams());
    } else {
      updateUrlParams(new URLSearchParams({ find: findValue }));
    }
  }

  function setFacetFilter(facetKey, value) {
    updateGlobalQueryParams(`f_${facetKey}`, value);
  }

  function clearSingleFacet(facetKey, value) {
    if (selectedFilters[facetKey]) {
      const currentValues = selectedFilters[facetKey];
      if (currentValues.includes(value)) {
        const filteredValues = currentValues.filter((entry) => entry !== value);
        if (filteredValues.length === 0) {
          setFacetFilter(facetKey, null);
        } else {
          setFacetFilter(facetKey, filteredValues);
        }
      }
    }
  }

  return jsxRuntime.jsxs("div", {
    className: "bloomreach-collection-app-container",
    children: [
      fetchError &&
        jsxRuntime.jsxs("div", {
          children: [
            jsxRuntime.jsx("h1", {
              className: "text-lg",
              children: "Error. Look at the logs for more info.",
            }),
            console.log("Fetch Bloomreach API error: ", fetchError),
          ],
        }),

      isLoading &&
        jsxRuntime.jsx(ProductGridSkeleton, {
          data: null,
          filtersCount: 0,
          showSkeletons: true,
        }),

      results &&
        jsxRuntime.jsxs(jsxRuntime.Fragment, {
          children: [
            jsxRuntime.jsx("div", { "data-filters-sentinel": true }),

            jsxRuntime.jsxs(FilterBar, {
              filterCount: appliedFiltersCount,
              clickHandler: openFiltersDrawer,
              children: [
                jsxRuntime.jsxs("div", {
                  className: "filter-container__count",
                  children: [
                    jsxRuntime.jsxs("span", {
                      className: "body-small",
                      children: [
                        results?.response?.numFound || 0,
                        " products",
                      ],
                    }),

                    jsxRuntime.jsx("button", {
                      className: "button-unstyled filter-container__view-toggle",
                      onClick: () => {
                        const nextView =
                          viewMode === "compact" ? "spacious" : "compact";
                        setViewMode(nextView);
                        localStorage.setItem("view", nextView);
                      },
                      children:
                        viewMode === "compact"
                          ? jsxRuntime.jsxs(jsxRuntime.Fragment, {
                              children: [
                                jsxRuntime.jsx(Icon, {
                                  name: "2-up",
                                  size: "m",
                                  className: "mobile-only",
                                }),
                                jsxRuntime.jsx(Icon, {
                                  name: "4-up",
                                  size: "m",
                                  className: "desktop-only",
                                }),
                              ],
                            })
                          : jsxRuntime.jsxs(jsxRuntime.Fragment, {
                              children: [
                                jsxRuntime.jsx(Icon, {
                                  name: "1-up",
                                  size: "m",
                                  className: "mobile-only",
                                }),
                                jsxRuntime.jsx(Icon, {
                                  name: "3-up",
                                  size: "m",
                                  className: "desktop-only",
                                }),
                              ],
                            }),
                    }),
                  ],
                }),

                appliedFiltersCount > 0 &&
                  jsxRuntime.jsx("div", {
                    className: "filter-container__chips",
                    children: jsxRuntime.jsx(SelectedFilterChips, {
                      selectedFilters,
                      facets: results?.facet_counts?.facets,
                      onFacetClear: clearSingleFacet,
                      onClearAll: clearAllFilters,
                      appliedFiltersCount,
                      hiddenLabel: true,
                    }),
                  }),
              ],
            }),

            jsxRuntime.jsx(FilterDrawer, {
              overlayRef,
              drawerRef,
              sort,
              selectedFilters,
              facets: results?.facet_counts?.facets,
              updateGlobalQueryParams,
              updateUrlParams,
              searchParams,
            }),

            jsxRuntime.jsxs("div", {
              className: "product-grid-container",
              children: [
                jsxRuntime.jsx(ProductGridSkeleton, {
                  data: results,
                  filtersCount: appliedFiltersCount,
                  view: viewMode,
                }),
                jsxRuntime.jsx(LoadMore, {
                  perPage: (page + 1) * perPage,
                  count: results?.response?.numFound,
                  onLoadMore: loadMore,
                }),
              ],
            }),
          ],
        }),
    ],
  });
}

function mountBloomreachCollection() {
  const root = document.getElementById("bloomreach-root");
  ReactDOMClient.createRoot(root).render(
    jsxRuntime.jsx(React.StrictMode, {
      children: jsxRuntime.jsx(BloomreachCollectionApp, {}),
    })
  );
}

mountBloomreachCollection();

document.addEventListener("shopify:section:load", (event) => {
  if (
    event.target.querySelector('[data-section-type="bloomreach-collection"]')
  ) {
    mountBloomreachCollection();
  }
});